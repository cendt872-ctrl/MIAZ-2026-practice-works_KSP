"""Локальний вебзастосунок Streamlit для класифікації коротких українськомовних текстів.

Запуск:  streamlit run app.py

Ембеддинги й прогнози обчислюються локально на CPU; тексти не надсилаються до зовнішніх API.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from common import (
    CLASSIFIER_PATH,
    DEMO_PATH,
    LABEL_HINTS,
    LABEL_NAMES,
    LOCAL_MODEL_DIR,
    MODEL_NAME,
    MODEL_URL,
    count_tokens,
    embed,
    load_classifier_bundle,
    load_encoder,
    max_tokens,
)

st.set_page_config(page_title="Інтелектуальне сортування документів", page_icon="📄")


@st.cache_resource(show_spinner="Завантаження моделі MiniLM…")
def get_encoder():
    # Застосунок не завантажує модель з інтернету сам: першим кроком є train.py.
    return load_encoder(allow_download=False)


@st.cache_resource(show_spinner="Завантаження класифікатора…")
def get_bundle(path: str, mtime: float):
    # mtime входить до ключа кешу: після перенавчання класифікатор перечитується.
    return load_classifier_bundle(Path(path))


@st.cache_data
def get_demo_examples() -> pd.DataFrame:
    if DEMO_PATH.is_file():
        return pd.read_csv(DEMO_PATH, encoding="utf-8")
    return pd.DataFrame(columns=["id", "text"])


st.title("📄 Інтелектуальне сортування документів")
st.caption(
    "Навчальний мініпроєкт: готова модель MiniLM перетворює текст на вектор, "
    "класифікатор LogisticRegression, навчений на 45 синтетичних прикладах, визначає категорію."
)

with st.expander("Категорії та обмеження", expanded=False):
    for lab, name in LABEL_NAMES.items():
        st.markdown(f"**{name}** — {LABEL_HINTS[lab]}.")
    st.markdown(
        "Це спрощена навчальна класифікація за домінантним комунікативним призначенням. "
        "Короткий уривок не завжди дозволяє встановити тип повного документа. "
        "Не вводьте службову інформацію, персональні дані чи відомості з обмеженим доступом."
    )
    st.markdown(f"Модель ембеддингів: [{MODEL_NAME}]({MODEL_URL})")

# --- Перевірка готовності ------------------------------------------------------
if not CLASSIFIER_PATH.is_file():
    st.error(
        "Класифікатор ще не навчений. Виконайте в терміналі в каталозі проєкту:\n\n"
        "`python train.py`\n\nпісля чого оновіть сторінку."
    )
    st.stop()

try:
    encoder = get_encoder()
except FileNotFoundError:
    st.error(
        f"Локальну копію моделі не знайдено ({LOCAL_MODEL_DIR}). "
        "Запустіть `python train.py` з доступом до інтернету: модель буде завантажено й збережено локально."
    )
    st.stop()

try:
    bundle = get_bundle(str(CLASSIFIER_PATH), CLASSIFIER_PATH.stat().st_mtime)
except Exception as exc:  # пошкоджений або несумісний файл
    st.error(f"Не вдалося завантажити класифікатор: {exc}. Перенавчіть його: `python train.py`.")
    st.stop()

clf = bundle["classifier"]
limit = max_tokens(encoder)

# --- Введення --------------------------------------------------------------------
demo = get_demo_examples()
if "text_input" not in st.session_state:
    st.session_state.text_input = ""

if len(demo):
    options = ["—"] + [f"{r.id}: {r.text[:70]}…" for r in demo.itertuples()]
    choice = st.selectbox("Вставити демонстраційний приклад (необов'язково)", options)
    if st.button("Вставити приклад", disabled=choice == "—"):
        st.session_state.text_input = demo.iloc[options.index(choice) - 1]["text"]

text = st.text_area(
    "Текст українською мовою (1–3 речення)",
    key="text_input",
    height=140,
    placeholder="Вставте короткий текст…",
)

if st.button("Класифікувати", type="primary"):
    cleaned = text.strip()
    if not cleaned:
        st.warning("Введіть текст для класифікації.")
        st.stop()

    n_tokens = count_tokens(encoder, cleaned)
    if n_tokens > limit:
        st.warning(
            f"Текст містить {n_tokens} токенів, а модель обробляє не більше {limit}. "
            "Частину тексту наприкінці буде відкинуто, тож результат стосуватиметься лише початку."
        )

    with st.spinner("Обчислення…"):
        vector = embed(encoder, [cleaned])
        label = clf.predict(vector)[0]
        scores = clf.predict_proba(vector)[0]

    st.subheader(f"Категорія: {LABEL_NAMES[label]}")
    st.caption(LABEL_HINTS[label])

    table = pd.DataFrame(
        {
            "Категорія": [LABEL_NAMES[c] for c in clf.classes_],
            "Оцінка predict_proba": scores,
        }
    ).sort_values("Оцінка predict_proba", ascending=False)
    st.dataframe(
        table,
        hide_index=True,
        column_config={
            "Оцінка predict_proba": st.column_config.ProgressColumn(
                format="%.2f", min_value=0.0, max_value=1.0
            )
        },
    )
    st.info(
        "Оцінки predict_proba показують відносну впевненість класифікатора, "
        "а не гарантовану ймовірність правильності: на малому наборі вони можуть бути некаліброваними."
    )
    st.caption(f"Довжина тексту: {n_tokens} токенів (обмеження моделі — {limit}).")
