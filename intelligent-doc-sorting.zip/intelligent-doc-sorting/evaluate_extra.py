"""Прогнози для демонстраційного та додаткового діагностичного наборів.

Запуск (після train.py):  python evaluate_extra.py

* data/demo_examples.csv — 5 нових текстів для показу; не використовувалися
  ні для навчання, ні для вибору параметрів.
* data/diagnostic_examples.csv — складні тексти зі змішаними ознаками.
  Це ДОДАТКОВИЙ діагностичний набір, сформований окремо від основного оцінювання;
  його результати НЕ входять до тестових метрик із results/metrics.json.
"""

from __future__ import annotations

import sys

import pandas as pd

from common import (
    DEMO_PATH,
    DIAGNOSTIC_PATH,
    LABEL_NAMES,
    RESULTS_DIR,
    embed,
    load_classifier_bundle,
    load_encoder,
)


def run(path, title, encoder, clf) -> pd.DataFrame:
    df = pd.read_csv(path, encoding="utf-8")
    X = embed(encoder, df["text"])
    pred = clf.predict(X)
    proba = clf.predict_proba(X)
    out = df.copy()
    out["predicted_label"] = pred
    out["expected"] = out["expected_label"].map(LABEL_NAMES)
    out["predicted"] = [LABEL_NAMES[p] for p in pred]
    out["match"] = out["predicted_label"] == out["expected_label"]
    for k, lab in enumerate(clf.classes_):
        out[f"score_{lab}"] = proba[:, k].round(4)

    print("\n" + "=" * 72 + f"\n{title}\n" + "=" * 72)
    for _, r in out.iterrows():
        mark = "збіг" if r["match"] else "НЕЗБІГ"
        scores = ", ".join(
            f"{LABEL_NAMES[lab]}: {r[f'score_{lab}']:.2f}" for lab in clf.classes_
        )
        amb = ""
        if "ambiguous_labeling" in out.columns:
            amb = f" | неоднозначна розмітка: {r['ambiguous_labeling']}"
        print(f"[{r['id']}] {r['text']}")
        print(f"   очікувано: {r['expected']} | прогноз: {r['predicted']} ({mark}){amb}")
        print(f"   оцінки predict_proba: {scores}")
    print(f"\nЗбігів: {int(out['match'].sum())} з {len(out)}")
    return out


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    bundle = load_classifier_bundle()
    clf = bundle["classifier"]
    encoder = load_encoder(allow_download=False)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    demo = run(DEMO_PATH, "ДЕМОНСТРАЦІЙНИЙ НАБІР (5 нових текстів)", encoder, clf)
    demo.to_csv(RESULTS_DIR / "demo_predictions.csv", index=False, encoding="utf-8-sig")

    diag = run(
        DIAGNOSTIC_PATH,
        "ДОДАТКОВИЙ ДІАГНОСТИЧНИЙ НАБІР (сформовано після основного оцінювання; "
        "до тестових метрик не входить)",
        encoder,
        clf,
    )
    diag.to_csv(RESULTS_DIR / "diagnostic_predictions.csv", index=False, encoding="utf-8-sig")

    wrong = diag[~diag["match"]]
    if len(wrong):
        print("\nНезбіги в діагностичному наборі. Якщо ambiguous_labeling = «так», "
              "незбіг може відображати неоднозначність ручної розмітки, а не лише помилку моделі.")
    print(f"\nРезультати: {RESULTS_DIR / 'demo_predictions.csv'}, "
          f"{RESULTS_DIR / 'diagnostic_predictions.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
