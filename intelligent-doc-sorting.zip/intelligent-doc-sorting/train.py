"""Навчання й оцінювання класифікатора поверх ембеддингів MiniLM.

Запуск:  python train.py

Протокол:
1. Читання data/documents.csv (60 текстів, по 20 на клас) і перевірка дублікатів.
2. Стратифікований поділ 75/25 з random_state=42.
3. Ембеддинги готовою моделлю MiniLM (ваги не змінюються).
4. Baseline DummyClassifier(most_frequent) і LogisticRegression з параметрами,
   визначеними ЗАЗДАЛЕГІДЬ (без підбору за тестовою вибіркою).
5. Метрики на тестовій частині, збереження класифікатора, повторне завантаження
   й перевірка, що прогнози відтворюються.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
)
from sklearn.model_selection import train_test_split

from common import (
    ARTIFACTS_DIR,
    CLASSIFIER_PATH,
    LABEL_NAMES,
    LABELS,
    MODEL_NAME,
    RANDOM_STATE,
    RESULTS_DIR,
    TEST_SIZE,
    embed,
    load_classifier_bundle,
    load_dataset,
    load_encoder,
    max_tokens,
    count_tokens,
)

# Параметри класифікатора зафіксовано до будь-якого оцінювання.
CLASSIFIER_PARAMS = {"C": 1.0, "max_iter": 2000, "random_state": RANDOM_STATE}

# Пороги лише для попереджень про можливі близькі перефразування між частинами.
LEXICAL_WARN = 0.45   # Жаккар за символьними 4-грамами
COSINE_WARN = 0.90    # косинусна подібність ембеддингів


def char_ngrams(text: str, n: int = 4) -> set[str]:
    t = " ".join(text.lower().split())
    return {t[i : i + n] for i in range(max(len(t) - n + 1, 1))}


def jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a | b else 0.0


def section(title: str) -> None:
    print("\n" + "=" * 72 + f"\n{title}\n" + "=" * 72)


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Дані -----------------------------------------------------------------
    section("1. Дані")
    df = load_dataset()
    print(f"Усього текстів: {len(df)}")
    for lab in LABELS:
        print(f"  {LABEL_NAMES[lab]:<28} {int((df['label'] == lab).sum())}")

    # 2. Поділ ----------------------------------------------------------------
    section("2. Стратифікований поділ 75% / 25% (random_state=42)")
    train_df, test_df = train_test_split(
        df,
        test_size=TEST_SIZE,
        stratify=df["label"],
        random_state=RANDOM_STATE,
    )
    train_df = train_df.reset_index(drop=True)
    test_df = test_df.reset_index(drop=True)
    split_counts = pd.DataFrame(
        {
            "Категорія": [LABEL_NAMES[l] for l in LABELS],
            "Навчання": [int((train_df["label"] == l).sum()) for l in LABELS],
            "Тест": [int((test_df["label"] == l).sum()) for l in LABELS],
        }
    )
    split_counts.loc[len(split_counts)] = ["Разом", len(train_df), len(test_df)]
    print(split_counts.to_string(index=False))
    split_counts.to_csv(RESULTS_DIR / "split_counts.csv", index=False, encoding="utf-8-sig")
    pd.concat(
        [train_df.assign(split="train"), test_df.assign(split="test")]
    ).to_csv(RESULTS_DIR / "split_assignment.csv", index=False, encoding="utf-8-sig")

    # Перевірка лексичної близькості між навчальною і тестовою частинами.
    lex_pairs = []
    train_grams = [char_ngrams(t) for t in train_df["text"]]
    for i, t_test in enumerate(test_df["text"]):
        g = char_ngrams(t_test)
        for j, g_train in enumerate(train_grams):
            s = jaccard(g, g_train)
            if s >= LEXICAL_WARN:
                lex_pairs.append((test_df.loc[i, "id"], train_df.loc[j, "id"], round(s, 3)))
    max_lex = max(
        jaccard(char_ngrams(a), b) for a in test_df["text"] for b in train_grams
    )
    print(f"\nМаксимальна лексична подібність тест↔навчання (Жаккар 4-грам): {max_lex:.3f}")
    if lex_pairs:
        print(f"УВАГА: пари з подібністю ≥ {LEXICAL_WARN}: {lex_pairs}")

    # 3. Ембеддинги -------------------------------------------------------------
    section("3. Ембеддинги готовою моделлю MiniLM (ваги не змінюються)")
    encoder = load_encoder(allow_download=True)
    limit = max_tokens(encoder)
    # У нових версіях метод перейменовано; підтримуємо обидві назви.
    get_dim = getattr(encoder, "get_embedding_dimension", None) or encoder.get_sentence_embedding_dimension
    dim = get_dim()
    print(f"Модель: {MODEL_NAME}")
    print(f"Розмірність ембеддингу: {dim}; обмеження довжини (max_seq_length): {limit} токенів")
    lengths = [count_tokens(encoder, t) for t in df["text"]]
    print(f"Довжина текстів набору в токенах: мін {min(lengths)}, макс {max(lengths)}")
    if max(lengths) > limit:
        print("УВАГА: частина текстів довша за обмеження й буде обрізана моделлю.")

    X_train = embed(encoder, train_df["text"])
    X_test = embed(encoder, test_df["text"])
    y_train = train_df["label"].to_numpy()
    y_test = test_df["label"].to_numpy()

    # Семантична близькість тест↔навчання (вектори нормалізовані → скалярний добуток = косинус).
    sim = X_test @ X_train.T
    top = []
    for i in range(sim.shape[0]):
        j = int(np.argmax(sim[i]))
        top.append(
            {
                "test_id": test_df.loc[i, "id"],
                "nearest_train_id": train_df.loc[j, "id"],
                "cosine": round(float(sim[i, j]), 4),
                "same_label": bool(y_test[i] == y_train[j]),
            }
        )
    top_df = pd.DataFrame(top).sort_values("cosine", ascending=False)
    top_df.to_csv(RESULTS_DIR / "nearest_train_neighbors.csv", index=False, encoding="utf-8-sig")
    print(f"Максимальна косинусна подібність тест↔навчання: {top_df['cosine'].max():.3f}")
    close = top_df[top_df["cosine"] >= COSINE_WARN]
    if len(close):
        print(f"УВАГА: можливі близькі перефразування (cos ≥ {COSINE_WARN}):")
        print(close.to_string(index=False))

    # 4. Навчання -------------------------------------------------------------
    section("4. Навчання baseline і LogisticRegression")
    baseline = DummyClassifier(strategy="most_frequent")
    baseline.fit(X_train, y_train)
    clf = LogisticRegression(**CLASSIFIER_PARAMS)
    clf.fit(X_train, y_train)
    print(f"Параметри LogisticRegression (зафіксовані заздалегідь): {CLASSIFIER_PARAMS}")

    # 5. Оцінювання -----------------------------------------------------------
    section("5. Оцінювання на тестовій частині")
    y_base = baseline.predict(X_test)
    y_pred = clf.predict(X_test)
    proba = clf.predict_proba(X_test)

    metrics = {
        "baseline_most_frequent": {
            "accuracy": round(float(accuracy_score(y_test, y_base)), 4),
            "macro_f1": round(float(f1_score(y_test, y_base, labels=LABELS, average="macro", zero_division=0)), 4),
            "predicted_class": str(y_base[0]),
        },
        "logistic_regression": {
            "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
            "macro_f1": round(float(f1_score(y_test, y_pred, labels=LABELS, average="macro", zero_division=0)), 4),
            "correct": int((y_pred == y_test).sum()),
            "total": int(len(y_test)),
        },
    }
    print(f"{'Модель':<34}{'Accuracy':>10}{'Macro-F1':>10}")
    print(f"{'Baseline (most_frequent)':<34}{metrics['baseline_most_frequent']['accuracy']:>10.3f}"
          f"{metrics['baseline_most_frequent']['macro_f1']:>10.3f}")
    print(f"{'MiniLM + LogisticRegression':<34}{metrics['logistic_regression']['accuracy']:>10.3f}"
          f"{metrics['logistic_regression']['macro_f1']:>10.3f}")
    print(f"\nПравильних відповідей: {metrics['logistic_regression']['correct']} "
          f"з {metrics['logistic_regression']['total']}")
    print("Примітка: baseline завжди обирає один клас "
          f"({LABEL_NAMES[metrics['baseline_most_frequent']['predicted_class']]}); "
          "за рівної кількості прикладів scikit-learn бере першу мітку в алфавітному порядку.")

    target_names = [LABEL_NAMES[l] for l in LABELS]
    report_txt = classification_report(
        y_test, y_pred, labels=LABELS, target_names=target_names, digits=3, zero_division=0
    )
    report_dict = classification_report(
        y_test, y_pred, labels=LABELS, target_names=target_names, output_dict=True, zero_division=0
    )
    print("\nPrecision / Recall / F1 за класами:\n" + report_txt)
    metrics["logistic_regression"]["per_class"] = {
        name: {k: round(float(v), 4) for k, v in report_dict[name].items()} for name in target_names
    }

    cm = confusion_matrix(y_test, y_pred, labels=LABELS)
    cm_df = pd.DataFrame(
        cm,
        index=[f"Факт: {LABEL_NAMES[l]}" for l in LABELS],
        columns=[f"Прогноз: {LABEL_NAMES[l]}" for l in LABELS],
    )
    print("Матриця помилок (рядки — істинний клас, стовпці — прогноз):")
    print(cm_df.to_string())
    cm_df.to_csv(RESULTS_DIR / "confusion_matrix.csv", encoding="utf-8-sig")
    metrics["logistic_regression"]["confusion_matrix"] = {
        "labels": target_names,
        "matrix": cm.tolist(),
    }

    pred_df = test_df[["id", "text", "label"]].copy()
    pred_df["expected"] = [LABEL_NAMES[l] for l in y_test]
    pred_df["predicted"] = [LABEL_NAMES[l] for l in y_pred]
    pred_df["correct"] = y_pred == y_test
    for k, lab in enumerate(clf.classes_):
        pred_df[f"score_{lab}"] = proba[:, k].round(4)
    pred_df.to_csv(RESULTS_DIR / "test_predictions.csv", index=False, encoding="utf-8-sig")

    errors = pred_df[~pred_df["correct"]]
    errors.to_csv(RESULTS_DIR / "misclassified.csv", index=False, encoding="utf-8-sig")
    print(f"\nПомилково класифіковано на тесті: {len(errors)}")
    for _, r in errors.iterrows():
        print(f"  [{r['id']}] {r['text']}\n      очікувано: {r['expected']}; прогноз: {r['predicted']}")
    if errors.empty:
        print("  Помилок на тестовій частині немає. Для демонстрації помилки виконайте "
              "python evaluate_extra.py (додатковий діагностичний набір).")

    # 6. Збереження та повторне завантаження ----------------------------------
    section("6. Збереження та повторне завантаження класифікатора")
    bundle = {
        "classifier": clf,
        "labels": LABELS,
        "label_names": LABEL_NAMES,
        "model_name": MODEL_NAME,
        "embedding_dim": int(dim),
        "max_seq_length": int(limit),
        "classifier_params": CLASSIFIER_PARAMS,
        "trained_on": "навчальна частина (75%) стратифікованого поділу, random_state=42",
        "n_train": int(len(train_df)),
        "sklearn_version": sklearn.__version__,
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    joblib.dump(bundle, CLASSIFIER_PATH)
    reloaded = load_classifier_bundle(CLASSIFIER_PATH)["classifier"]
    same = bool(np.array_equal(reloaded.predict(X_test), y_pred)) and bool(
        np.allclose(reloaded.predict_proba(X_test), proba)
    )
    print(f"Збережено: {CLASSIFIER_PATH}")
    print(f"Прогнози після повторного завантаження збігаються: {'так' if same else 'НІ'}")

    metrics["meta"] = {
        "model_name": MODEL_NAME,
        "embedding_dim": int(dim),
        "max_seq_length": int(limit),
        "n_total": int(len(df)),
        "n_train": int(len(train_df)),
        "n_test": int(len(test_df)),
        "random_state": RANDOM_STATE,
        "classifier_params": CLASSIFIER_PARAMS,
        "max_lexical_similarity_test_train": round(float(max_lex), 4),
        "max_cosine_similarity_test_train": float(top_df["cosine"].max()),
        "reload_check_passed": same,
        "sklearn_version": sklearn.__version__,
        "created_utc": bundle["created_utc"],
    }
    with open(RESULTS_DIR / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    with open(RESULTS_DIR / "classification_report.txt", "w", encoding="utf-8") as f:
        f.write(report_txt)

    print(f"\nРезультати збережено в каталозі {RESULTS_DIR}")
    print("Обмеження: 15 тестових прикладів — дуже мала вибірка; одна помилка змінює "
          "accuracy приблизно на 6,7 п.п. Результати не свідчать про придатність "
          "до роботи з реальними документами.")
    return 0 if same else 1


if __name__ == "__main__":
    raise SystemExit(main())
