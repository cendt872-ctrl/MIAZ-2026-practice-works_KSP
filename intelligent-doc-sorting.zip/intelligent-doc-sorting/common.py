"""Спільні налаштування й допоміжні функції проєкту «Інтелектуальне сортування документів».

Розподіл ролей:
* готова нейромережева модель MiniLM (Sentence Transformers) лише перетворює текст
  на вектор (ембеддинг); її ваги в проєкті не змінюються;
* класифікатор LogisticRegression (scikit-learn) навчається на власному
  синтетичному наборі даних і визначає категорію за ембеддингом.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pandas as pd

# Вимикаємо телеметрію бібліотек Hugging Face. Тексти користувача
# в будь-якому разі обробляються локально й нікуди не надсилаються.
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")

ROOT = Path(__file__).resolve().parent

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
MODEL_URL = "https://huggingface.co/sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

# Локальна копія моделі. Можна перевизначити змінною середовища MINILM_LOCAL_DIR
# (наприклад, якщо модель скопійовано на ПК без доступу до інтернету).
LOCAL_MODEL_DIR = Path(
    os.environ.get("MINILM_LOCAL_DIR", ROOT / "models" / "paraphrase-multilingual-MiniLM-L12-v2")
)

DATA_DIR = ROOT / "data"
DATASET_PATH = DATA_DIR / "documents.csv"
DEMO_PATH = DATA_DIR / "demo_examples.csv"
DIAGNOSTIC_PATH = DATA_DIR / "diagnostic_examples.csv"

ARTIFACTS_DIR = ROOT / "artifacts"
CLASSIFIER_PATH = ARTIFACTS_DIR / "classifier.joblib"
RESULTS_DIR = ROOT / "results"

RANDOM_STATE = 42
TEST_SIZE = 0.25

# Порядок класів фіксований: він використовується в метриках і матриці помилок.
LABELS = ["informational", "analytical", "organizational"]
LABEL_NAMES = {
    "informational": "Інформаційне повідомлення",
    "analytical": "Аналітична довідка",
    "organizational": "Організаційний документ",
}
LABEL_HINTS = {
    "informational": "повідомляє про факт, подію або стан справ без розгорнутого аналізу та вимог",
    "analytical": "зіставляє дані, пояснює причини, оцінює тенденції, робить висновки чи припущення",
    "organizational": "визначає порядок дій, завдання, строки, відповідальних або правила роботи",
}


def _local_model_exists(path: Path) -> bool:
    return path.is_dir() and (path / "modules.json").is_file()


def load_encoder(allow_download: bool = True):
    """Завантажує MiniLM на CPU.

    Якщо локальна копія є — використовує її (інтернет не потрібен).
    Інакше одноразово завантажує модель з Hugging Face Hub і зберігає локально.
    """
    from sentence_transformers import SentenceTransformer

    if _local_model_exists(LOCAL_MODEL_DIR):
        return SentenceTransformer(str(LOCAL_MODEL_DIR), device="cpu")

    if not allow_download:
        raise FileNotFoundError(
            f"Локальну копію моделі не знайдено в {LOCAL_MODEL_DIR}. "
            "Запустіть train.py з доступом до інтернету для першого завантаження."
        )

    print(f"Локальної копії немає. Завантаження моделі {MODEL_NAME} (потрібен інтернет)...")
    encoder = SentenceTransformer(MODEL_NAME, device="cpu")
    LOCAL_MODEL_DIR.mkdir(parents=True, exist_ok=True)
    encoder.save(str(LOCAL_MODEL_DIR))
    print(f"Модель збережено локально: {LOCAL_MODEL_DIR}")
    return encoder


def embed(encoder, texts) -> np.ndarray:
    """Перетворює список текстів на нормалізовані ембеддинги (L2-норма = 1).

    Нормалізація не навчається на даних, тому не створює витоку інформації з тестової частини.
    """
    return encoder.encode(
        list(texts),
        batch_size=16,
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False,
    )


def count_tokens(encoder, text: str) -> int:
    """Кількість токенів разом зі службовими, як її рахує токенізатор моделі."""
    # verbose=False прибирає службове попередження токенізатора про довгий текст:
    # саму модель обрізання захищає (encode обрізає вхід до max_seq_length).
    return len(encoder.tokenizer(text, add_special_tokens=True, verbose=False)["input_ids"])


def max_tokens(encoder) -> int:
    """Фактичне обмеження довжини з конфігурації завантаженої моделі."""
    return int(encoder.max_seq_length)


def load_dataset(path: Path = DATASET_PATH) -> pd.DataFrame:
    """Читає та перевіряє основний набір даних."""
    df = pd.read_csv(path, encoding="utf-8")
    required = {"id", "text", "label"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"У файлі {path} бракує полів: {sorted(missing)}")
    df["text"] = df["text"].astype(str).str.strip()
    if (df["text"] == "").any():
        raise ValueError("У наборі є порожні тексти.")
    unknown = set(df["label"]) - set(LABELS)
    if unknown:
        raise ValueError(f"Невідомі мітки: {sorted(unknown)}")
    if df["id"].duplicated().any():
        raise ValueError("Ідентифікатори id повторюються.")
    normalized = df["text"].str.lower().str.replace(r"\s+", " ", regex=True)
    if normalized.duplicated().any():
        dups = df.loc[normalized.duplicated(keep=False), "id"].tolist()
        raise ValueError(f"Знайдено дублікати текстів: {dups}")
    return df


def load_classifier_bundle(path: Path = CLASSIFIER_PATH) -> dict:
    """Завантажує збережений класифікатор разом із метаданими."""
    import joblib

    if not path.is_file():
        raise FileNotFoundError(
            f"Класифікатор не знайдено: {path}. Спочатку виконайте: python train.py"
        )
    bundle = joblib.load(path)
    if bundle.get("model_name") != MODEL_NAME:
        raise ValueError("Класифікатор навчено на ембеддингах іншої моделі; перенавчіть його.")
    return bundle
